import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "VORTEX TECHNO STUDIO | Suno.AI Music Forge & Sonic Roles Library",
  description:
    "The ultimate AI music studio for making all kinds of Techno with Suno.AI. Explore sound descriptions, sonic roles, Web Audio live synthesis, and smart prompt engineering.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-zinc-950 text-zinc-100 antialiased selection:bg-red-500 selection:text-white min-h-screen">
        {children}
      </body>
    </html>
  );
}
