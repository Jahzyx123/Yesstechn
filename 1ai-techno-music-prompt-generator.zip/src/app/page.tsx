'use client';

import React, { useState, useEffect } from 'react';
import Navigation from '@/components/Navigation';
import SunoPromptForge from '@/components/SunoPromptForge';
import SoundLibrarySection from '@/components/SoundLibrarySection';
import TechnoAuditionSequencer from '@/components/TechnoAuditionSequencer';
import RecipesSection from '@/components/RecipesSection';
import VaultSection from '@/components/VaultSection';
import AddSoundModal from '@/components/AddSoundModal';
import SoundLibraryModal from '@/components/SoundLibraryModal';
import {
  TechnoSubgenre,
  TechnoSound,
  TechnoRecipe,
  UserPrompt,
} from '@/db/schema';
import { INITIAL_SUBGENRES, INITIAL_SOUNDS, INITIAL_RECIPES } from '@/lib/seed-data';
import { Sparkles, Radio, Volume2, ShieldAlert } from 'lucide-react';

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<
    'forge' | 'sounds' | 'sequencer' | 'recipes' | 'vault'
  >('forge');

  const [subgenres, setSubgenres] = useState<TechnoSubgenre[]>(INITIAL_SUBGENRES);
  const [sounds, setSounds] = useState<TechnoSound[]>(INITIAL_SOUNDS);
  const [recipes, setRecipes] = useState<TechnoRecipe[]>(INITIAL_RECIPES);
  const [prompts, setPrompts] = useState<UserPrompt[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSeeding, setIsSeeding] = useState<boolean>(false);
  const [isAddSoundOpen, setIsAddSoundOpen] = useState<boolean>(false);
  const [isLibraryModalOpen, setIsLibraryModalOpen] = useState<boolean>(false);

  // Load all data on mount
  const fetchAllData = async () => {
    setIsLoading(true);
    try {
      const [subRes, sndRes, recRes, prmRes] = await Promise.all([
        fetch('/api/techno-subgenres'),
        fetch('/api/techno-sounds'),
        fetch('/api/techno-recipes'),
        fetch('/api/user-prompts'),
      ]);

      const subData = await subRes.json();
      const sndData = await sndRes.json();
      const recData = await recRes.json();
      const prmData = await prmRes.json();

      if (subData.success && Array.isArray(subData.data) && subData.data.length > 0) {
        setSubgenres(subData.data);
      }
      if (sndData.success && Array.isArray(sndData.data) && sndData.data.length > 0) {
        setSounds(sndData.data);
      }
      if (recData.success && Array.isArray(recData.data) && recData.data.length > 0) {
        setRecipes(recData.data);
      }
      if (prmData.success && Array.isArray(prmData.data)) {
        setPrompts(prmData.data);
      }
    } catch (error) {
      console.error('Failed to load data:', error);
      // Fallback to static seed data
      setSubgenres(INITIAL_SUBGENRES);
      setSounds(INITIAL_SOUNDS);
      setRecipes(INITIAL_RECIPES);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // Seed Database manually or reset
  const handleSeedDatabase = async () => {
    setIsSeeding(true);
    try {
      const res = await fetch('/api/seed');
      await res.json();
      await fetchAllData();
    } catch (err) {
      console.error('Error seeding DB:', err);
    } finally {
      setIsSeeding(false);
    }
  };

  // Like sound
  const handleLikeSound = async (id: string) => {
    try {
      const res = await fetch(`/api/techno-sounds/${id}/like`, { method: 'POST' });
      const json = await res.json();
      if (json.success && json.data) {
        setSounds(
          sounds.map((s) => {
            if (s.id === id) {
              return { ...s, likesCount: json.data.likesCount };
            }
            return s;
          })
        );
      } else {
        // Optimistic update fallback
        setSounds(
          sounds.map((s) => {
            if (s.id === id) {
              return { ...s, likesCount: s.likesCount + 1 };
            }
            return s;
          })
        );
      }
    } catch (error) {
      console.error('Like error:', error);
    }
  };

  // Add custom sound
  const handleAddSound = async (soundData: {
    name: string;
    category: string;
    sunoPromptDescription: string;
    whatItAddsToSong: string;
    synthRecipe: string;
    subgenres: string[];
  }) => {
    const res = await fetch('/api/techno-sounds', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(soundData),
    });
    const json = await res.json();
    if (json.success && json.data) {
      setSounds([json.data, ...sounds]);
    } else {
      throw new Error(json.error || 'Failed to save sound');
    }
  };

  // Save prompt to Vault
  const handleSavePrompt = async (promptData: {
    title: string;
    subgenreId: string;
    stylePrompt: string;
    lyricsArrangement: string;
    bpm: number;
    selectedSoundIds: string[];
    notes: string;
  }) => {
    const res = await fetch('/api/user-prompts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(promptData),
    });
    const json = await res.json();
    if (json.success && json.data) {
      setPrompts([json.data, ...prompts]);
    }
  };

  // Toggle favorite in Vault
  const handleToggleFavorite = async (id: string, isFavorite: boolean) => {
    try {
      await fetch(`/api/user-prompts/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isFavorite }),
      });
      setPrompts(
        prompts.map((p) => {
          if (p.id === id) {
            return { ...p, isFavorite };
          }
          return p;
        })
      );
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };

  // Delete prompt in Vault
  const handleDeletePrompt = async (id: string) => {
    try {
      await fetch(`/api/user-prompts/${id}`, { method: 'DELETE' });
      setPrompts(prompts.filter((p) => p.id !== id));
    } catch (error) {
      console.error('Error deleting prompt:', error);
    }
  };

  // Clone recipe into Forge
  const handleCloneRecipe = (recipe: TechnoRecipe) => {
    setActiveTab('forge');
    // We scroll smoothly to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Load Vault prompt into Forge
  const handleLoadVaultPrompt = (prompt: UserPrompt) => {
    setActiveTab('forge');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // From Sequencer send to Forge
  const handleSequencerToForge = (combinedKeywords: string, _soundNames: string[]) => {
    setActiveTab('forge');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-zinc-950 text-zinc-100">
      <Navigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onSeedDatabase={handleSeedDatabase}
        isSeeding={isSeeding}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-32 space-y-4">
            <div className="w-12 h-12 rounded-full border-4 border-red-500/20 border-t-red-500 animate-spin" />
            <p className="text-sm font-bold text-zinc-400">
              Bootstrapping Vortex Techno Studio &amp; AI Sound Vault...
            </p>
          </div>
        ) : (
          <>
            {activeTab === 'forge' && (
              <SunoPromptForge
                subgenres={subgenres}
                sounds={sounds}
                onSavePrompt={handleSavePrompt}
                onOpenSoundLibrary={() => setIsLibraryModalOpen(true)}
              />
            )}

            {activeTab === 'sounds' && (
              <SoundLibrarySection
                sounds={sounds}
                subgenres={subgenres}
                onLikeSound={handleLikeSound}
                onOpenAddModal={() => setIsAddSoundOpen(true)}
              />
            )}

            {activeTab === 'sequencer' && (
              <TechnoAuditionSequencer onSendToForge={handleSequencerToForge} />
            )}

            {activeTab === 'recipes' && (
              <RecipesSection
                recipes={recipes}
                subgenres={subgenres}
                onCloneToForge={handleCloneRecipe}
              />
            )}

            {activeTab === 'vault' && (
              <VaultSection
                prompts={prompts}
                subgenres={subgenres}
                onToggleFavorite={handleToggleFavorite}
                onDeletePrompt={handleDeletePrompt}
                onLoadIntoForge={handleLoadVaultPrompt}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 bg-zinc-950 py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-red-600 to-orange-500 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">VORTEX TECHNO STUDIO</p>
                <p className="text-xs text-zinc-400">
                  Built for Suno v3.5, Suno v4, and Underground Club Producers
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-zinc-400">
              <span className="flex items-center space-x-1">
                <Radio className="w-3.5 h-3.5 text-orange-400" />
                <span>Web Audio Synthesizer Enabled</span>
              </span>
              <span>•</span>
              <span>12 Techno Subgenres</span>
              <span>•</span>
              <span>40+ AI Timbre Descriptors</span>
              <span>•</span>
              <span>16-Step Audition Beat Lab</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AddSoundModal
        isOpen={isAddSoundOpen}
        onClose={() => setIsAddSoundOpen(false)}
        onAddSound={handleAddSound}
      />

      <SoundLibraryModal
        isOpen={isLibraryModalOpen}
        onClose={() => setIsLibraryModalOpen(false)}
        sounds={sounds}
        onInjectSound={() => {}}
      />
    </div>
  );
}
