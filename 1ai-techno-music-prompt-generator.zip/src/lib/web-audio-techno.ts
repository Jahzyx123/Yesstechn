// Web Audio API Synthesizer for live Techno Sound preview & Audition Sequencer

export interface WebAudioPreset {
  type:
    | 'kick_rumble'
    | 'acid_303'
    | 'dub_chord'
    | 'industrial_hit'
    | 'hihat_loop'
    | 'drone_pad'
    | 'riser_fx'
    | 'vocal_hook'
    | 'sub_bass'
    | 'synth_lead';
  freq?: number;
  decay?: number;
  cutoff?: number;
  resonance?: number;
  delay?: boolean;
  reverb?: boolean;
  distortion?: number;
  note?: string;
}

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

// Helper to create a distortion curve
function makeDistortionCurve(amount: number): Float32Array {
  const k = typeof amount === 'number' ? amount : 50;
  const n_samples = 44100;
  const buffer = new ArrayBuffer(n_samples * 4);
  const curve = new Float32Array(buffer);
  const deg = Math.PI / 180;
  for (let i = 0; i < n_samples; ++i) {
    const x = (i * 2) / n_samples - 1;
    curve[i] = ((3 + k) * x * 20 * deg) / (Math.PI + k * Math.abs(x));
  }
  return curve;
}

// Generate white/pink noise buffer
function createNoiseBuffer(ctx: AudioContext, duration: number): AudioBuffer {
  const bufferSize = ctx.sampleRate * duration;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = Math.random() * 2 - 1;
  }
  return buffer;
}

/**
 * Play a synthesized techno sound preview based on preset type
 */
export function playTechnoSound(preset: WebAudioPreset): void {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const gainNode = ctx.createGain();
    gainNode.connect(ctx.destination);

    switch (preset.type) {
      case 'kick_rumble': {
        // 1. Kick Drum Sweep
        const osc = ctx.createOscillator();
        const kickGain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.exponentialRampToValueAtTime(35, now + 0.12);
        
        kickGain.gain.setValueAtTime(1.0, now);
        kickGain.gain.exponentialRampToValueAtTime(0.001, now + (preset.decay || 0.45));

        // 2. Sub-Bass Sidechain Rumble
        const subOsc = ctx.createOscillator();
        const subGain = ctx.createGain();
        subOsc.type = 'sine';
        subOsc.frequency.setValueAtTime(preset.freq || 52, now);
        
        // Sidechain dip when kick hits, swell after
        subGain.gain.setValueAtTime(0.05, now);
        subGain.gain.linearRampToValueAtTime(0.45, now + 0.18);
        subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);

        // Optional distortion
        if (preset.distortion && preset.distortion > 0) {
          const waveShaper = ctx.createWaveShaper();
          waveShaper.curve = makeDistortionCurve(preset.distortion * 40) as any;
          osc.connect(kickGain);
          kickGain.connect(waveShaper);
          waveShaper.connect(ctx.destination);
        } else {
          osc.connect(kickGain);
          kickGain.connect(ctx.destination);
        }

        subOsc.connect(subGain);
        subGain.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + 0.45);
        subOsc.start(now);
        subOsc.stop(now + 0.6);
        break;
      }

      case 'acid_303': {
        // TB-303 Acid Sawtooth with Resonant Filter Sweep
        const osc = ctx.createOscillator();
        const filter = ctx.createBiquadFilter();
        const amp = ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(preset.freq || 130.81, now); // C3

        filter.type = 'lowpass';
        filter.Q.value = preset.resonance || 16;
        filter.frequency.setValueAtTime(150, now);
        filter.frequency.exponentialRampToValueAtTime(preset.cutoff || 1800, now + 0.12);
        filter.frequency.exponentialRampToValueAtTime(280, now + 0.38);

        amp.gain.setValueAtTime(0.6, now);
        amp.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

        osc.connect(filter);
        filter.connect(amp);
        amp.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + 0.42);
        break;
      }

      case 'dub_chord': {
        // Minor 7th Chord with Filter & Simulated Tape Delay
        const freqs = [261.63, 311.13, 392.00, 466.16]; // C minor 7
        const masterAmp = ctx.createGain();
        masterAmp.gain.setValueAtTime(0.25, now);
        masterAmp.gain.exponentialRampToValueAtTime(0.001, now + (preset.decay || 0.8));

        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1200, now);
        filter.frequency.exponentialRampToValueAtTime(400, now + 0.4);

        // Echo delay
        const delayNode = ctx.createDelay();
        delayNode.delayTime.value = 0.28; // Tape 3/8 delay
        const feedback = ctx.createGain();
        feedback.gain.value = 0.42;

        delayNode.connect(feedback);
        feedback.connect(delayNode);
        feedback.connect(ctx.destination);

        freqs.forEach((freq) => {
          const osc = ctx.createOscillator();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(freq, now);
          osc.connect(filter);
          osc.start(now);
          osc.stop(now + (preset.decay || 0.8));
        });

        filter.connect(masterAmp);
        masterAmp.connect(ctx.destination);
        if (preset.delay !== false) {
          masterAmp.connect(delayNode);
        }
        break;
      }

      case 'industrial_hit': {
        // Metallic FM anvil strike
        const carrier = ctx.createOscillator();
        const modulator = ctx.createOscillator();
        const modGain = ctx.createGain();
        const hitGain = ctx.createGain();

        carrier.type = 'square';
        carrier.frequency.setValueAtTime(preset.freq || 680, now);

        modulator.type = 'sawtooth';
        modulator.frequency.setValueAtTime((preset.freq || 680) * 1.414, now);

        modGain.gain.setValueAtTime(800, now);
        modGain.gain.exponentialRampToValueAtTime(10, now + 0.25);

        hitGain.gain.setValueAtTime(0.4, now);
        hitGain.gain.exponentialRampToValueAtTime(0.001, now + (preset.decay || 0.3));

        modulator.connect(modGain);
        modGain.connect(carrier.frequency);

        const waveShaper = ctx.createWaveShaper();
        waveShaper.curve = makeDistortionCurve(60) as any;

        carrier.connect(hitGain);
        hitGain.connect(waveShaper);
        waveShaper.connect(ctx.destination);

        modulator.start(now);
        carrier.start(now);
        modulator.stop(now + 0.35);
        carrier.stop(now + 0.35);
        break;
      }

      case 'hihat_loop': {
        // Metallic 909 Open / Closed Hat sample
        const noise = createNoiseBuffer(ctx, 0.2);
        const source = ctx.createBufferSource();
        source.buffer = noise;

        const filter = ctx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.setValueAtTime(preset.freq || 6000, now);

        const amp = ctx.createGain();
        amp.gain.setValueAtTime(0.4, now);
        amp.gain.exponentialRampToValueAtTime(0.001, now + (preset.decay || 0.15));

        source.connect(filter);
        filter.connect(amp);
        amp.connect(ctx.destination);

        source.start(now);
        source.stop(now + (preset.decay || 0.15));
        break;
      }

      case 'drone_pad': {
        // Warehouse Cavernous Drone Chord
        const freqs = [110, 164.81, 220, 261.63]; // A minor drone
        const padAmp = ctx.createGain();
        padAmp.gain.setValueAtTime(0.01, now);
        padAmp.gain.linearRampToValueAtTime(0.2, now + 0.4);
        padAmp.gain.exponentialRampToValueAtTime(0.001, now + 2.2);

        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(preset.cutoff || 600, now);

        freqs.forEach((f, idx) => {
          const osc = ctx.createOscillator();
          osc.type = idx % 2 === 0 ? 'sawtooth' : 'triangle';
          osc.frequency.setValueAtTime(f, now);
          osc.connect(filter);
          osc.start(now);
          osc.stop(now + 2.3);
        });

        filter.connect(padAmp);
        padAmp.connect(ctx.destination);
        break;
      }

      case 'riser_fx': {
        // White noise rising filter sweep
        const duration = preset.decay || 1.2;
        const noise = createNoiseBuffer(ctx, duration);
        const source = ctx.createBufferSource();
        source.buffer = noise;

        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.Q.value = 12;
        filter.frequency.setValueAtTime(300, now);
        filter.frequency.exponentialRampToValueAtTime(preset.cutoff || 3500, now + duration * 0.85);

        const amp = ctx.createGain();
        amp.gain.setValueAtTime(0.2, now);
        amp.gain.exponentialRampToValueAtTime(0.001, now + duration);

        source.connect(filter);
        filter.connect(amp);
        amp.connect(ctx.destination);

        source.start(now);
        source.stop(now + duration);
        break;
      }

      case 'vocal_hook': {
        // Synthesized formant vocal chant effect using bandpass filters
        const osc = ctx.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(146.83, now); // D3
        osc.frequency.setValueAtTime(130.81, now + 0.2); // C3

        const formantFilter = ctx.createBiquadFilter();
        formantFilter.type = 'bandpass';
        formantFilter.frequency.setValueAtTime(750, now); // Formant peak
        formantFilter.Q.value = 8;

        const amp = ctx.createGain();
        amp.gain.setValueAtTime(0.4, now);
        amp.gain.exponentialRampToValueAtTime(0.001, now + (preset.decay || 0.5));

        osc.connect(formantFilter);
        formantFilter.connect(amp);
        amp.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + (preset.decay || 0.5));
        break;
      }

      case 'sub_bass': {
        // Rolling 16th Sub Bass pulse
        const osc = ctx.createOscillator();
        const amp = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(preset.freq || 65, now);

        amp.gain.setValueAtTime(0.7, now);
        amp.gain.exponentialRampToValueAtTime(0.001, now + (preset.decay || 0.3));

        osc.connect(amp);
        amp.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + 0.35);
        break;
      }

      case 'synth_lead': {
        // Futuristic Detroit syncopated synth note
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const amp = ctx.createGain();
        const filter = ctx.createBiquadFilter();

        const baseFreq = preset.freq || 330;
        osc1.type = 'sawtooth';
        osc2.type = 'square';
        osc1.frequency.setValueAtTime(baseFreq, now);
        osc2.frequency.setValueAtTime(baseFreq * 1.005, now); // Slightly detuned

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(preset.cutoff || 1500, now);

        amp.gain.setValueAtTime(0.35, now);
        amp.gain.exponentialRampToValueAtTime(0.001, now + (preset.decay || 0.35));

        osc1.connect(filter);
        osc2.connect(filter);
        filter.connect(amp);
        amp.connect(ctx.destination);

        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + (preset.decay || 0.35));
        osc2.stop(now + (preset.decay || 0.35));
        break;
      }

      default: {
        const osc = ctx.createOscillator();
        const amp = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        amp.gain.setValueAtTime(0.3, now);
        amp.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.connect(amp);
        amp.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.3);
      }
    }
  } catch (error) {
    console.error('WebAudio preview error:', error);
  }
}
